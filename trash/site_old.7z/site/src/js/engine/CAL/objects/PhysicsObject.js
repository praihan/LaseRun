this.CAL = this.CAL || {};

this.CAL.objects = this.CAL.objects || {};

(function(undefined) {
    "use strict";
    
    var PhysicsObject = function(world, bodyDef, fixtureDef, userData) {
        PhysicsObject.super[0].call(this);
        delete this._size;
        delete this._location;
        if (world && bodyDef && fixtureDef) {
            var body = this._body = world.CreateBody(bodyDef); 
            body.SetUserData(userData || this);
            this._fixture = body.CreateFixture(fixtureDef);
        } else {
            throw CAL.lang.exception("undefined", "Undefined params to PhysicsObject");
        }
    }
    
    CAL.lang.extend(PhysicsObject, CAL.objects.GameObject);
    
    var p = PhysicsObject.prototype;
    var s = PhysicsObject;

    p.bind = function(displayObject, converter) {
        var _this = this;
        return {
            converter: converter,
            host: _this,
            client: displayObject,
            update: function() {
                this.client.setX(this.converter.toPixels(this.host.getX()) - this.client.getWidth() / 2);
                this.client.setY(this.converter.toPixels(this.host.getY()) - this.client.getHeight() / 2);
                if (this.client.setRotation) {
                    this.client.setRotation(this.host.getRotation());
                }
            }
        }
    }

    p.getBody = function() {
        return this._body;
    }

    p.getFixture = function() {
        return this._fixture;
    }

    p.setLocation = function(x, y) {
        if (typeof y === "undefined") {
            y = x.y;
            x = x.x;
        }
        this.getBody().GetPosition().Set(x, y);
    }

    p.getLocation = function() {
        var pos = this.getBody().GetPosition();
        return CAL.graphics.Vector2(pos.x, pos.y);
    }

    p.setX = function(x) {
        this.getBody().GetPosition().x = x;
    }

    p.setY = function(y) {
        this.getBody().GetPosition().y = y;
    }

    p.getX = function() {
        return this.getBody().GetPosition().x;
    }

    p.getY = function() {
        return this.getBody().GetPosition().y;
    }

    p.getRotation = function() {
        return this.getBody().GetAngle();
    }

    delete p.setSize;

    delete p.setWidth;

    delete p.setHeight;

    delete p.getSize;
    
    delete p.getWidth;
    
    delete p.getHeight;

    delete p.scale;

    delete p.scaleWidth;
    
    delete p.scaleHeight
    
    delete p.scaleWidthTo

    delete p.scaleHeightTo
    
    delete p.scaleTo
    
    delete p.scaleByWidthTo
    
    delete p.scaleByHeightTo
    
    delete p.clone;




    CAL.objects.PhysicsObject = PhysicsObject;

})();