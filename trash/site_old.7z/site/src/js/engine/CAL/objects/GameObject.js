this.CAL = this.CAL || {};

this.CAL.objects = this.CAL.objects || {};

(function(undefined) {
	"use strict";
	
	var GameObject = function(world, bodyDef, fixtureDef) {
		GameObject.super[0].call(this);
		GameObject.super[1].call(this);
		this._updateListeners = [];
		this._drawListeners = [];
		if (world && bodyDef && fixtureDef) {
			var body = this._body = world.createBody(bodyDef);
			this._fixture = body.createFixture(fixtureDef);
		} else {
			this._body = null;
			this._fixture = null;
		}

	}
	
	CAL.lang.extend(GameObject, [CAL.graphics.DisplayObject, CAL.lang.IUpdateableObject]);
	
	var p = GameObject.prototype;
	var s = GameObject;
	
	p.on = function(eventName, callback, scope) {
		if (!callback) {
			return;
		}
		switch (eventName.toLowerCase()) {
			case "update":
				this._updateListeners.push({callback: callback, scope: scope || this});
				break;
			case "draw":
				this._drawListeners.push({callback: callback, scope: scope || this});
		}
	}

	p.getBody = function() {
		return this._body;
	}

	p.getFixture = function() {
		return this._fixture;
	}

	p.syncToBody = function() {
		var pos = this.getBody().GetPosition();
		GameObject.super[0].prototype.setX.call(this, pos.x);
		GameObject.super[0].prototype.setY.call(this, pos.y);
	}
	
	p.update = function(params) {
		for (var i = 0; i < this._updateListeners.length; ++i) {
			var e = this._updateListeners[i];
			e.callback.call(e.scope, this, params);
		}
		s.super[0].prototype.update.call(this, params);
	}
	
	p.draw = function(params) {
		for (var i = 0; i < this._drawListeners.length; ++i) {
			var e = this._drawListeners[i];
			e.callback.call(e.scope, this, params);
		}
		s.super[0].prototype.draw.call(this, params);
	}
	
	p.clone = function(object) {
		var rv = object || new GameObject();
		rv._updateListeners = this._updateListeners;
		rv._drawListeners = this._drawListeners;
		return rv;
	}
	
	CAL.objects.GameObject = GameObject;
	
})();