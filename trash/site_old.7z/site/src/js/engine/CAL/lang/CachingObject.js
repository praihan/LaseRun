this.CAL = this.CAL || {};

this.CAL.lang = this.CAL.lang || {};

(function(undefined) {
	"use strict";
	
	var CachingObject = function() {
		/**
		 *@dict
		 */
		this.cache = {};
	}
	
	CAL.lang.CachingObject = CachingObject;
	
})();