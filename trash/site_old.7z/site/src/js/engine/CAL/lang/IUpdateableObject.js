this.CAL = this.CAL || {};

this.CAL.lang = this.CAL.lang || {};

(function(undefined) {
	"use strict";
	
	var IUpdateableObject = function() {	
	}
	
	IUpdateableObject.prototype.update = function(params) {
	}
	
	CAL.lang.IUpdateableObject = IUpdateableObject;
	
})();