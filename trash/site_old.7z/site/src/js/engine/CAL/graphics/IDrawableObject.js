this.CAL = this.CAL || {};

this.CAL.graphics = this.CAL.graphics || {};

(function(undefined) {
	"use strict";
	
	var IDrawableObject = function() {	
	}
	
	IDrawableObject.prototype.draw = function(params) {
	}
	
	CAL.graphics.IDrawableObject = IDrawableObject;
	
})();