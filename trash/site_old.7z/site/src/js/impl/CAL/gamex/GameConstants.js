this.CAL = this.CAL || {};

this.CAL.gamex = this.CAL.gamex || {};

(function(undefined) {
	"use strict";
	
	CAL.gamex.TARGET_FPS = CAL.gamex.TARGET_FPS || 60;
	CAL.gamex.TARGET_UPDATE_FPS = CAL.gamex.TARGET_UPDATE_FPS || 1000;

    CAL.gamex.BOX2D_TO_PIXELS = 100;
    CAL.gamex.PIXELS_TO_BOX2D = 1 / CAL.gamex.BOX2D_TO_PIXELS;

    CAL.gamex.VELOCITY_ITERATIONS = 6;
    CAL.gamex.POSITION_ITERATIONS = 2;

    var toPixels = function(val) {
        return val * CAL.gamex.BOX2D_TO_PIXELS;
    };

    var toBox2D = function(val) {
        return val * CAL.gamex.PIXELS_TO_BOX2D;
    }

    CAL.gamex.b2Converter = {
        toPixels: toPixels,
        toPix: toPixels,
        p: toPixels,
        toBox2D: toBox2D,
        toBox: toBox2D,
        b: toBox2D 
    }
	
})();


