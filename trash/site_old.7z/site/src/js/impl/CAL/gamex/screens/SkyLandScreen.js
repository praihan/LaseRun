this.CAL = this.CAL || {};

this.CAL.gamex = this.CAL.gamex || {};

this.CAL.gamex.screens = this.CAL.gamex.screens || {};

(function(undefined) {
	"use strict";
	
	var LEVEL_NAME = "skyland";
	
	var SkyLandScreen = function() {
		SkyLandScreen.super[0].call(this, LEVEL_NAME);
	}
	
	CAL.lang.extend(SkyLandScreen, CAL.gamex.screens.LevelScreen);
	
	var p = SkyLandScreen.prototype;
	
	p.update = function(params) {
		var viewport = params.viewport;
		var Box2D = params.Box2D;
		var b2Converter = CAL.gamex.b2Converter;
		if (params.first) {
			var dm = this._dm = new CAL.graphics.DrawableManager();
			var pm = this._pm = new CAL.graphics.DrawableManager();
			
			var lvl = this.getLevelName();
			
			var res = function(name) {
				return params.resources.getResult(lvl + "/" + name);
			}
			var skySprite,
				groundSprite,
				floorSprite,
				floorSprite2,
				redBallSprite;

			dm.push(skySprite = new CAL.objects.TexturedObject(new CAL.graphics.ParallaxSprite({
				image: res("sky"),
			})), "sky");
			
			dm.push(groundSprite = new CAL.objects.TexturedObject(new CAL.graphics.ParallaxSprite({
				image: res("ground"),
			})), "ground");
			
			dm.push(redBallSprite = new CAL.objects.TexturedObject(new CAL.graphics.Sprite({
				image: res("chars/red_ball"),
			})), "red_ball");

			dm.push(floorSprite = new CAL.objects.TexturedObject(new CAL.graphics.ParallaxSprite({
				image: res("floor"),
			})), "floor");
			
			dm.push(floorSprite2 = new CAL.objects.TexturedObject(new CAL.graphics.ParallaxSprite({
				image: res("floor"),
			})), "floor2");
			
			var BALL_RADIUS = 20;

			skySprite.scaleTo(params.viewport);
			
			groundSprite.scaleWidthTo(viewport.x);
			groundSprite.scaleHeightTo(viewport.y / 4);
			groundSprite.setY(viewport.y - groundSprite.getHeight());
					
			floorSprite.scaleWidthTo(viewport.x / 2);
			floorSprite.scaleHeightTo(viewport.y / 50);
			floorSprite.setY(groundSprite.getY() - floorSprite.getHeight());
			
			floorSprite2.scaleWidthTo(viewport.x / 2);
			floorSprite2.scaleHeightTo(viewport.y / 50);
			floorSprite2.setY(floorSprite.getY());
			floorSprite2.setX(floorSprite.getX() + floorSprite.getWidth());

			redBallSprite.scaleWidthTo(BALL_RADIUS * 2);
			redBallSprite.scaleHeightTo(BALL_RADIUS * 2);
			redBallSprite.setLocation((viewport.x - redBallSprite.getWidth()) / 2, (viewport.y - redBallSprite.getHeight()) / 2);

			var world = this._world = new Box2D.b2World(new Box2D.b2Vec2(0, 9.8), true);

			var ballBodyDef = new Box2D.b2BodyDef();

			var groundPObject = new CAL.objects.PhysicsObject(
				world, 
				Box2D.newBodyDef(function() {
					this.type = Box2D.b2Body.b2_staticBody;
					this.position.Set(
						b2Converter.b(groundSprite.getCenterX()), 
						b2Converter.b(groundSprite.getCenterY())
					);
				}), 
				Box2D.newFixtureDef(function() {
					this.density = 10;
					this.friction = 10;
					this.restitution = 0.6;
					this.shape = Box2D.newShape(Box2D.b2PolygonShape, function() {
						this.SetAsBox(
							b2Converter.b(groundSprite.getWidth() / 2), 
							b2Converter.b(groundSprite.getHeight() / 2)
						);
					});
				})
			);

			var ballPObject = new CAL.objects.PhysicsObject(
				world, 
				Box2D.newBodyDef(function() {
					this.type = Box2D.b2Body.b2_dynamicBody;
					this.position.Set(
						b2Converter.b(redBallSprite.getCenterX()), 
						b2Converter.b(redBallSprite.getCenterY())
					);
				}), 
				Box2D.newFixtureDef(function() {
					this.density = 10;
					this.friction = 12;
					this.restitution = 0.6;
					this.shape = Box2D.newShape(Box2D.b2CircleShape, function() {
						this.SetRadius(b2Converter.b(redBallSprite.getWidth() / 2));
					});
				})
			);
			pm.push(groundPObject.bind(groundSprite, b2Converter), "floor");
			pm.push(ballPObject.bind(redBallSprite,  b2Converter), "red_ball");

		} else {
			var delta = params.tickEvent.delta;
			var pm = this._pm;
			
			var right = params.keyboard.isDown("right");
			var left = params.keyboard.isDown("left");
			
			var scrollVel = right ^ left ? right ? 3e-1 : -3e-1 : 0;	
			
			var currentPosition;
			var r;
			var redBall;
			// if (scrollVel) {
				redBall = this._pm.get("red_ball").host;
				r = redBall.getFixture().GetShape().GetRadius();
				var b = redBall.getBody();
				currentPosition = CAL.graphics.Vector2(b.GetPosition());
				b.ApplyImpulse(
					new Box2D.b2Vec2(scrollVel * delta / 1000, 0), 
					b.GetWorldPoint(new Box2D.b2Vec2(scrollVel > 0 ? -r : r, -r))
				);
			// }

			this._world.Step(delta / 1000, CAL.gamex.VELOCITY_ITERATIONS, CAL.gamex.POSITION_ITERATIONS);
			this._pm.update(params);

			// if (scrollVel) {
				var deltaX = b.GetPosition().x - currentPosition.x;
				var dm = this._dm;
				var sky = dm.get("sky");
				var baseWidth = sky.getTexture()._image.width;
				var s = function(spr, modifier) {
					spr.getTexture().scrollX(b2Converter.p(deltaX) * delta * (spr.getTexture()._image.width / baseWidth) * (modifier ? modifier : 1));
				}
				s(sky, 0.3);
				s(dm.get("floor"), 2);
				s(dm.get("floor2"), 2);
				s(dm.get("ground"));
				// redBall.getBody().SetPositionAndAngle(currentPosition, redBall.getBody().GetAngle());
			// }

		}
		

	}
	
	p.draw = function(params) {
		this._dm.draw(params);
	}
	
	CAL.gamex.screens.SkyLandScreen = SkyLandScreen;
	
})();