From The Open Bundle
http://open.commonly.cc

- - -

This is the Platformer Graphics Art Pack. (Deluxe)

All art is by Kenney Vleugels, the creator of 50+ Flash games, including 
Jack Russell, Ballista, Retron, Colorbot, Armor Picross, Trid, and Pico's School DX.

Website: www.kenney.nl
Facebook: www.facebook.com/KenneyNL
Twitter: @KenneyWings

- - -

UPDATED 6/26: Vector art files, in SVG & SWF format.